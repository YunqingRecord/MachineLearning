'''
Q4c.py
Time: 16/04/2019
Student: ZHAO Yunqing
Course: ELEC 6008


Info:
Q4c (this .py file) is of all-feature learning, by using Hard-Margin SVM
'''

import numpy as np
import matplotlib.pyplot as plt
from cvxopt import solvers
from cvxopt import matrix
import glob


def read_and_screen(path, feature):           # Append the occurrence vector of each txt file in Train and Text matrix
    Vector = []
    global t
    contents = glob.glob(path)
    for t in contents:
        current = []
        f = open(t, 'r')
        f = f.read()
        for i in f:
            if i in sign:                     # Screen the illegal signs
                f = f.replace(i, '')
        f = f.split(' ')
        for featr in feature:
            current.append(f.count(featr))    # Count and append occurrence row
        Vector.append(current)

    return Vector


if __name__ == '__main__':
    # sign = [',', '.', "?", "!", "(", ")", '%', "&", "*", "-"]  # sign to be screened
    sign = [',', '.']
    f2 = open('../data/feature.txt', 'r')  # open the feature file
    features = f2.read().split()  # read the feature
    features_new = ['car', 'hotel']
    label = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
             -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1]

    X_train = np.array(read_and_screen(path='../train_data/*.txt', feature=features))  # input vector for train set
    X_test = np.array(read_and_screen(path='../test_data/*.txt', feature=features))    # input vector for test set
    Y_train = np.array(label)

    X1 = X_train[0:20, :]
    X2 = X_train[20:40, :]
    X = np.concatenate((X1, X2), axis=0)

    Y1 = np.concatenate((np.ones((20, 1)), X1), axis=1)
    Y2 = np.concatenate((np.ones((20, 1)) * -1, -X2), axis=1)
    Y = np.concatenate((Y1, Y2), axis=0)

    A = matrix(np.concatenate((Y1, Y2), axis=0), tc='d')

    b = matrix(-1*np.ones((40, 1)), tc='d')

    q1 = np.zeros((1, 14))
    Q2 = np.concatenate((np.zeros((13, 1)), np.eye(13)), axis=1)
    Q = np.concatenate((q1, Q2), axis=0)

    Q = matrix(2*Q, tc='d')
    q = matrix(np.zeros((14, 1)), tc='d')

    sol = solvers.qp(Q, q, A, b)
    a_con = sol['x']

    Y_test_0 = np.array([[-1], [-1], [-1], [-1], [-1]])
    Y_test_1 = np.array([[1], [1], [1], [1], [1]])

    X_test_01 = np.array(X_test[0, :])
    X_test_02 = np.array(X_test[3, :])
    X_test_03 = np.array(X_test[4, :])
    X_test_04 = np.array(X_test[5, :])
    X_test_05 = np.array(X_test[8, :])
    X_test_0 = np.concatenate((X_test_01, X_test_02, X_test_03, X_test_04, X_test_05), axis=0)
    X_test_0 = X_test_0.reshape((5, 13))

    X_test_11 = np.array(X_test[1, :])
    X_test_12 = np.array(X_test[2, :])
    X_test_13 = np.array(X_test[6, :])
    X_test_14 = np.array(X_test[7, :])
    X_test_15 = np.array(X_test[9, :])
    X_test_1 = np.concatenate((X_test_11, X_test_12, X_test_13, X_test_14, X_test_15), axis=0)
    X_test_1 = X_test_1.reshape((5, 13))

    Y3_0 = np.concatenate((Y_test_0, -X_test_0), axis=1)
    Y3_1 = np.concatenate((Y_test_1, X_test_1), axis=1)

    Y3 = np.concatenate((Y3_1, Y3_0), axis=0)
    ans = np.dot(Y3, a_con)
    flag = 0
    for i in range(10):
        if ans[i] > 0:
            flag += 1
    print("Accuracy by SVM with all-feature:", (flag / 10) * 100, "%")
