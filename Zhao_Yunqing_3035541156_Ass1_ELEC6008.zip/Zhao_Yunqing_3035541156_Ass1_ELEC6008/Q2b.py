'''
Q2b.py
Time: 16/04/2019
Student: ZHAO Yunqing
Course: ELEC 6008
'''

'''
Part 1:  for 01.txt only
Count the occurrence of each keyword of “features” in “01.txt” 
and Store the results in the first row of a matrix called Xtrain_text1.
'''

import glob
import numpy as np
f = open('../data/01.txt', 'r')        # open the pointed text file
text1 = f.read()                       # read the opened file f

sign = [',', '.', "?", "!", "(", ")", '%', "&", "*", "-"]                      # sign to be screened

for i in text1:
    if i in sign:
        text1 = text1.replace(i, '')   # filter the sign in text file

text1 = text1.split(' ')               # split the screened text1 by whitespace

f2 = open('../data/feature.txt', 'r')  # open the feature file
features = f2.read().split()           # read the feature

Xtrain_text1 = []

print("Author:Zhao_Yunqing")
print("In 01.txt:")
print()
for feature in features:               # Count occurrence number in text1
    Xtrain_text1.append(text1.count(feature))
    print("Occurrence of", feature, ":", text1.count(feature))
print()
print("Xtrain_text1:", Xtrain_text1)

'''
Part 2:  for all training txt files
Count the occurrence of each keyword of “features” in the range of “01-40.txt” 
and Store the results in the xx-th row of a matrix called Xtrain.
'''


def read_and_screen(path, feature):    # Append the occurrence vector of each txt file in Train and Text matrix
    Vector = []
    global t
    contents = glob.glob(path)
    for t in contents:
        current = []
        f = open(t, 'r')
        f = f.read()
        for i in f:
            if i in sign:      # Screen the illegal signs
                f = f.replace(i, '')
        f = f.split(' ')
        for featr in feature:
            current.append(f.count(featr))   # Count and append occurrence row
        Vector.append(current)

    return Vector


label = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]

X_train = np.array(read_and_screen(path='../train_data/*.txt', feature=features))    # Gain input vector for training set
X_test = np.array(read_and_screen(path='../test_data/*.txt', feature=features))      # Gain input vector for testing set
Y_train = np.array(label)

print("X_train_shape:", X_train.shape)
print("X_train:", X_train)
print()

print("X_test_shape:", X_test.shape)
print("X_test:", X_test)
print()

print("Y_train_shape:", Y_train.shape)
print("Y_train:", Y_train)

