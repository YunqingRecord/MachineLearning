'''
Q2a.py
Time: 16/04/2019
Student: ZHAO Yunqing
Course: ELEC 6008
'''

f = open('../data/01.txt', 'r')        # open the pointed text file
text1 = f.read()                       # read the opened file f

sign = [',', '.']                      # sign to be screened

for i in text1:
    if i in sign:
        text1 = text1.replace(i, '')   # filter the sign in text file

text1 = text1.split(' ')               # split the screened text1 by whitespace

f2 = open('../data/feature.txt', 'r')  # open the feature file
features = f2.read().split()           # read the feature

feature1 = features[0]                 # extract the 1st key word : "car"

occurrence = text1.count(feature1)     # count the number of occurrence of pointed feature1 in text 1
print("occurance:", occurrence)
