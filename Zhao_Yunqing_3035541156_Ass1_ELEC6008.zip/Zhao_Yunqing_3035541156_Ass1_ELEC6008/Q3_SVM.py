'''
Q3_SVM.py
Time: 16/04/2019
Student: ZHAO Yunqing
Course: ELEC 6008
'''

import numpy as np
import matplotlib.pyplot as plt
from cvxopt import solvers
from cvxopt import matrix
import glob


def read_and_screen(path, feature):           # Append the occurrence vector of each txt file in Train and Text matrix
    Vector = []
    global t
    contents = glob.glob(path)
    for t in contents:
        current = []
        f = open(t, 'r')
        f = f.read()
        for i in f:
            if i in sign:                     # Screen the illegal signs
                f = f.replace(i, '')
        f = f.split(' ')
        for featr in feature:
            current.append(f.count(featr))    # Count and append occurrence row
        Vector.append(current)

    return Vector


if __name__ == '__main__':
    # sign = [',', '.', "?", "!", "(", ")", '%', "&", "*", "-"]  # sign to be screened
    sign = [',', '.']
    f2 = open('../data/feature.txt', 'r')  # open the feature file
    features = f2.read().split()  # read the feature
    features_new = ['car', 'hotel']
    label = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
             -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1]

    X_train = np.array(read_and_screen(path='../train_data/*.txt', feature=features_new))  # input vector for train set
    # X_test = np.array(read_and_screen(path='../test_data/*.txt', feature=features_new))    # input vector for test set
    Y_train = np.array(label)

    X1 = X_train[0:20, :]
    X2 = X_train[20:40, :]
    X = np.concatenate((X1, X2), axis=0)

    Y1 = np.concatenate((np.ones((20, 1)), X1), axis=1)
    Y2 = np.concatenate((np.ones((20, 1)) * -1, -X2), axis=1)
    Y = np.concatenate((Y1, Y2), axis=0)

    A = matrix(np.concatenate((Y1, Y2), axis=0), tc='d')

    b = matrix(-1*np.ones((40, 1)), tc='d')

    q1 = np.zeros((1, 3))
    Q2 = np.concatenate((np.zeros((2, 1)), np.eye(2)), axis=1)
    Q = np.concatenate((q1, Q2), axis=0)

    Q = matrix(2*Q, tc='d')
    q = matrix(np.zeros((3, 1)), tc='d')

    sol = solvers.qp(Q, q, A, b)
    a_con = sol['x']

    x = np.arange(-1, 7, 0.1)
    y = -(a_con[0]+a_con[1]*x)/a_con[2]

    axes = plt.gca()

    axes.set_xlabel('car')
    axes.set_ylabel('hotel')

    axes.set_xlim([-1, 7])
    axes.set_ylim([-1, 7])

    plt.title("Scatter plot divided by Hard-Margin SVM")
    plt.scatter(X1.transpose()[0], X1.transpose()[1], s=75, alpha=.5)
    plt.scatter(X2.transpose()[0], X2.transpose()[1], s=75, alpha=.5)
    legend = ['Class 1', 'Class 2']
    plt.legend(legend)

    plt.plot(x, y)

    plt.show()
