'''
Q4a.py
Time: 16/04/2019
Student: ZHAO Yunqing
Course: ELEC 6008


Info:
Q4a (this .py file) is just for 2-feature learning
'''

# import libraries
import glob
import numpy as np
import matplotlib.pyplot as plt


def read_and_screen(path, feature):          # Append the occurrence vector of each txt file in Train and Text matrix
    Vector = []
    global t
    contents = glob.glob(path)
    for t in contents:
        current = []
        f = open(t, 'r')
        f = f.read()
        for i in f:
            if i in sign:                    # Screen the illegal signs
                f = f.replace(i, '')
        f = f.split(' ')
        for featr in feature:
            current.append(f.count(featr))   # Count and append occurrence row
        Vector.append(current)

    return Vector


if __name__ == '__main__':
    # sign = [',', '.', "?", "!", "(", ")", '%', "&", "*", "-"]  # sign to be screened
    sign = [',', '.']
    # f2 = open('../data/feature.txt', 'r')  # open the feature file
    # features = f2.read().split()  # read the feature
    features_new = ['car', 'hotel']
    label = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
             -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1]

    X_train = np.array(read_and_screen(path='../train_data/*.txt', feature=features_new))  # input vector for train set
    X_test = np.array(read_and_screen(path='../test_data/*.txt', feature=features_new))    # input vector for test set
    Y_train = np.array(label)

    X1 = X_train[0:20, :]
    X2 = X_train[20:40, :]
    X = np.concatenate((X1, X2), axis=0)
    Y1 = np.concatenate((np.ones((20, 1)) * -1, -X1), axis=1)
    Y2 = np.concatenate((np.ones((20, 1)), X2), axis=1)
    Y = np.concatenate((Y1, Y2), axis=0)
    # Initialize
    a = np.zeros((3, 1))
    # no. of misclassified samples
    sum_wrong = 1

    # Perceptron
    a_iter = a
    k = 0
    while sum_wrong > 0 and k < 1000:
        wrong = np.dot(Y, a_iter) <= 0
        sum_wrong = sum(wrong)
        sum1 = sum(wrong * np.ones((1, 3)) * Y)
        a_iter = a_iter + sum1.reshape(3, 1)
        k = k + 1
    a_con = a_iter

    Y_test_0 = np.array([[-1], [-1], [-1], [-1], [-1]])
    Y_test_1 = np.array([[1], [1], [1], [1], [1]])

    X_test_01 = np.array(X_test[0, :])
    X_test_02 = np.array(X_test[3, :])
    X_test_03 = np.array(X_test[4, :])
    X_test_04 = np.array(X_test[5, :])
    X_test_05 = np.array(X_test[8, :])
    X_test_0 = np.concatenate((X_test_01, X_test_02, X_test_03, X_test_04, X_test_05), axis=0)
    X_test_0 = X_test_0.reshape((5, 2))

    X_test_11 = np.array(X_test[1, :])
    X_test_12 = np.array(X_test[2, :])
    X_test_13 = np.array(X_test[6, :])
    X_test_14 = np.array(X_test[7, :])
    X_test_15 = np.array(X_test[9, :])
    X_test_1 = np.concatenate((X_test_11, X_test_12, X_test_13, X_test_14, X_test_15), axis=0)
    X_test_1 = X_test_1.reshape((5, 2))

    Y3_0 = np.concatenate((Y_test_0, -X_test_0), axis=1)
    Y3_1 = np.concatenate((Y_test_1, X_test_1), axis=1)

    Y3 = np.concatenate((Y3_1, Y3_0), axis=0)
    ans = np.dot(Y3, a_con)
    flag = 0
    for i in range(10):
        if ans[i] > 0:
            flag += 1
    print("Accuracy by Perceptron Learning with 2-feature:", (flag/10)*100, "%")


'''
Hard-margin SVM is proved to be error when learning 2-dimension-feature samples
'''